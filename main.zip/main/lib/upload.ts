import { Platform } from "react-native";

import { getApiBaseUrl } from "@/constants/oauth";

export type UploadAsset = {
  uri: string;
  name: string;
  size?: number;
  mimeType?: string;
  file?: Blob;
};

type UploadResponse = {
  url: string;
  name: string;
  size: number;
  mimeType: string;
};

function absoluteApiUrl(endpoint: string) {
  const baseUrl = getApiBaseUrl();
  if (!baseUrl) return endpoint;
  return `${baseUrl.replace(/\/$/, "")}/${endpoint.replace(/^\//, "")}`;
}

function toPublicUrl(value: string) {
  if (/^https?:\/\//i.test(value)) return value;
  const baseUrl = getApiBaseUrl();
  return baseUrl ? `${baseUrl.replace(/\/$/, "")}/${value.replace(/^\//, "")}` : value;
}

function appendAsset(formData: FormData, asset: UploadAsset) {
  if (Platform.OS === "web" && asset.file) {
    formData.append("file", asset.file, asset.name);
    return;
  }

  formData.append(
    "file",
    {
      uri: asset.uri,
      name: asset.name,
      type: asset.mimeType || "application/octet-stream",
    } as unknown as Blob,
  );
}

async function upload(endpoint: string, asset: UploadAsset): Promise<UploadResponse & { url: string }> {
  const formData = new FormData();
  appendAsset(formData, asset);

  const response = await fetch(absoluteApiUrl(endpoint), {
    method: "POST",
    body: formData,
  });

  const payload = (await response.json().catch(() => ({}))) as Partial<UploadResponse> & {
    error?: string;
  };
  if (!response.ok || !payload.url) {
    throw new Error(payload.error || "Upload failed. Please try again.");
  }

  return {
    url: toPublicUrl(payload.url),
    name: payload.name || asset.name,
    size: payload.size ?? asset.size ?? 0,
    mimeType: payload.mimeType || asset.mimeType || "application/octet-stream",
  };
}

export function uploadImage(asset: UploadAsset) {
  return upload("/api/upload/image", asset);
}

export function uploadFile(asset: UploadAsset) {
  return upload("/api/upload/file", asset);
}
