# DFF LINK

**DOLFLEX FF — IMAGE / FILE TO LINK** is a focused Expo utility for turning images and files into shareable URLs. It intentionally contains only two workflows: **IMAGE → LINK** and **FILE → LINK**.

## Package identity

- Android package / iOS bundle identifier: `com.dolflexff.link`
- Expo project: `dff-link`
- Frontend: Expo SDK 54, React Native, Expo Router, TypeScript, NativeWind-compatible theme tokens
- Backend: Express, multipart validation, ImgBB image forwarding, Manus permanent file storage

## Features

- Select an image, upload it server-side to ImgBB, and receive the direct image URL.
- Select any file, permanently store it using the project’s S3-compatible storage, and receive a shareable `/files/...` URL.
- Copy, open, or share every generated link.
- Native iOS / Android pickers plus Expo Web compatibility.
- Inline loading, success, empty, and error states with accessible touch targets.

## Run locally

```bash
pnpm install
pnpm dev
```

The dev command starts the Express API and Expo Metro Web preview together. For Expo Web only:

```bash
pnpm dev:metro
```

For a native development client:

```bash
pnpm android
pnpm ios
```

## Environment configuration

Create a local `.env` from `.env.example` when running outside the managed WebDev environment:

```bash
cp .env.example .env
```

Required values:

- `IMGBB_API_KEY`: server-only ImgBB API key. In a managed project, configure this through the secure project Secret Box. Never place the real value in `.env`, GitHub, Expo public variables, or mobile client code.
- `EXPO_PUBLIC_API_BASE_URL`: API origin for native builds, for example `https://your-api.example.com`. Expo Web derives the API origin from the managed `8081` preview host when this value is omitted.
- `BUILT_IN_FORGE_API_URL` and `BUILT_IN_FORGE_API_KEY`: provided by the managed runtime for permanent file storage.

The ImgBB credential has been validated against the official `POST https://api.imgbb.com/1/upload` endpoint using a minimal test upload. The validation test is in `tests/imgbb.secret.test.ts`.

## API

### `GET /api/health`

Returns a lightweight server health response.

### `POST /api/upload/image`

Accepts a multipart form field named `file`. The server validates image MIME type and size, then forwards the image to ImgBB without exposing the API key to the client.

### `POST /api/upload/file`

Accepts a multipart form field named `file`. The server validates the file, assigns a unique storage key, permanently stores it through the project storage helper, and returns a generated URL.

### `GET /files/*`

Redirects a generated file URL to a signed storage URL. Generated URLs remain stable at the application route while storage access is handled server-side.

## Checks and tests

```bash
pnpm check
pnpm test
pnpm build
```

The ImgBB secret test requires the secure `IMGBB_API_KEY` environment variable and makes one minimal validation upload. Do not run it with a key you do not intend to use for a test upload.

## Android build

Use the standard Expo / EAS workflow after setting the final application credentials:

```bash
npx expo prebuild
npx eas build -p android
```

The configured Android package is `com.dolflexff.link`. Review signing credentials and app-store metadata before submitting a production build.

## GitHub readiness

The repository excludes local secrets and build artifacts. Before pushing:

1. Confirm no `.env` or real API key is staged.
2. Configure `IMGBB_API_KEY` through the deployment secret manager.
3. Set `EXPO_PUBLIC_API_BASE_URL` for native builds.
4. Run `pnpm check && pnpm test && pnpm build`.
5. Verify the Image → Link and File → Link flows against a real device and Expo Web.
