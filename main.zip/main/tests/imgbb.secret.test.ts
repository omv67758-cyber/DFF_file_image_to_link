import { describe, expect, it } from "vitest";

const transparentPixelBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";

describe("ImgBB secret", () => {
  it("accepts the configured API key for a minimal upload", async () => {
    const apiKey = process.env.IMGBB_API_KEY;
    expect(apiKey, "IMGBB_API_KEY must be configured in the secure project environment").toBeTruthy();

    const body = new URLSearchParams({
      key: apiKey!,
      image: transparentPixelBase64,
      name: "dff-link-secret-check.png",
    });
    const response = await fetch("https://api.imgbb.com/1/upload", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    });
    const payload = (await response.json()) as { success?: boolean; error?: { message?: string } };

    expect(response.ok, payload.error?.message ?? `ImgBB request failed with ${response.status}`).toBe(true);
    expect(payload.success).toBe(true);
  }, 30_000);
});
