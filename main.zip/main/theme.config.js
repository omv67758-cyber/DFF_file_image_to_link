/** @type {const} */
const themeColors = {
  primary: { light: '#0B6E9D', dark: '#0B6E9D' },
  background: { light: '#ffffff', dark: '#ffffff' },
  surface: { light: '#F6F9FB', dark: '#F6F9FB' },
  foreground: { light: '#0B1014', dark: '#0B1014' },
  muted: { light: '#6D7780', dark: '#6D7780' },
  border: { light: '#DCE4E9', dark: '#DCE4E9' },
  success: { light: '#16754A', dark: '#16754A' },
  warning: { light: '#55B7E8', dark: '#55B7E8' },
  error: { light: '#B42318', dark: '#B42318' },
};

module.exports = { themeColors };
