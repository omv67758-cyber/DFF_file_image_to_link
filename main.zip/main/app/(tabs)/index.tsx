import * as Clipboard from "expo-clipboard";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import * as WebBrowser from "expo-web-browser";
import { useState, type ComponentProps } from "react";
import { useFonts, SpaceGrotesk_400Regular, SpaceGrotesk_500Medium, SpaceGrotesk_600SemiBold, SpaceGrotesk_700Bold } from "@expo-google-fonts/space-grotesk";
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";

import { ScreenContainer } from "@/components/screen-container";
import { uploadFile, uploadImage, type UploadAsset } from "@/lib/upload";

type Screen = "home" | "image" | "file";
type UploadResult = { url: string; name: string; size: number; mimeType: string };
const C = { white: "#FFFFFF", ink: "#0B1014", sky: "#0B6E9D", skySoft: "#E1F3FB", grey: "#66747E", line: "#B9D6E3", soft: "#F3F9FC", success: "#16754A", error: "#B42318" };

function bytes(value?: number) {
  if (!value) return "Size unavailable";
  if (value < 1024) return `${value} B`;
  if (value < 1048576) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1048576).toFixed(1)} MB`;
}
function typeLabel(asset: UploadAsset) {
  if (asset.mimeType) return asset.mimeType;
  const ext = asset.name.split(".").pop();
  return ext ? `${ext.toUpperCase()} file` : "File";
}
async function haptic() {
  if (Platform.OS !== "web") await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <View style={[styles.brand, compact && styles.brandCompact]}>
    <View style={styles.brandRule} />
    <Text style={styles.brandName}>DOLFLEX FF</Text>
    <Text style={styles.brandDescriptor}>IMAGE <Text style={styles.brandSlash}>/</Text> FILE TO LINK</Text>
  </View>;
}

function FeatureCard({ icon, title, description, onPress }: { icon: ComponentProps<typeof MaterialIcons>["name"]; title: string; description: string; onPress: () => void }) {
  return <Pressable onPress={async () => { await haptic(); onPress(); }} style={({ pressed }) => [styles.featureCard, pressed && styles.featurePressed]} accessibilityRole="button" accessibilityLabel={title}>
    <View style={styles.featureIcon}><MaterialIcons name={icon} size={22} color={C.ink} /></View>
    <View style={styles.featureCopy}><Text style={styles.featureTitle}>{title}</Text><Text style={styles.featureDescription}>{description}</Text></View>
    <MaterialIcons name="arrow-forward" size={20} color={C.sky} />
  </Pressable>;
}

function Home({ onSelect }: { onSelect: (screen: "image" | "file") => void }) {
  return <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-white">
    <View pointerEvents="none" style={styles.backgroundWashTop} /><View pointerEvents="none" style={styles.backgroundWashBottom} />
    <ScrollView contentContainerStyle={styles.homeContent} showsVerticalScrollIndicator={false}>
      <View style={styles.statusRow}><View style={styles.statusDot} /><Text style={styles.statusText}>LINK UTILITY · 01</Text></View>
      <Brand />
      <Text style={styles.hero}>Turn your images and files into shareable links — quickly and easily.</Text>
      <View style={styles.sectionHeader}><Text style={styles.eyebrow}>CHOOSE A FLOW</Text><Text style={styles.sectionHint}>Two tools. No clutter.</Text></View>
      <View style={styles.cardStack}>
        <FeatureCard icon="image" title="IMAGE → LINK" description="Upload an image and generate a direct link instantly." onPress={() => onSelect("image")} />
        <FeatureCard icon="description" title="FILE → LINK" description="Upload a file and generate a shareable link." onPress={() => onSelect("file")} />
      </View>
      <View style={styles.footer}><View style={styles.footerLine} /><View style={styles.footerMeta}><Text style={styles.footerText}>FAST</Text><Text style={styles.footerDot}>•</Text><Text style={styles.footerText}>SIMPLE</Text><Text style={styles.footerDot}>•</Text><Text style={styles.footerText}>SHAREABLE</Text></View></View>
    </ScrollView>
  </ScreenContainer>;
}

function Upload({ kind, onBack }: { kind: "image" | "file"; onBack: () => void }) {
  const isImage = kind === "image";
  const [asset, setAsset] = useState<UploadAsset | null>(null);
  const [result, setResult] = useState<UploadResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const pick = async () => {
    setError(""); setCopied(false);
    if (isImage) {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) { setError("Media access is needed to choose an image."); return; }
      const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: false, quality: 1 });
      if (picked.canceled) return;
      const item = picked.assets[0];
      setAsset({ uri: item.uri, name: item.fileName || `image-${Date.now()}.jpg`, size: item.fileSize, mimeType: item.mimeType || "image/jpeg", file: (item as ImagePicker.ImagePickerAsset & { file?: Blob }).file });
    } else {
      const picked = await DocumentPicker.getDocumentAsync({ type: "*/*", copyToCacheDirectory: true, multiple: false });
      if (picked.canceled) return;
      const item = picked.assets[0];
      setAsset({ uri: item.uri, name: item.name, size: item.size, mimeType: item.mimeType, file: (item as DocumentPicker.DocumentPickerAsset & { file?: Blob }).file });
    }
    setResult(null);
  };

  const upload = async () => {
    if (!asset || loading) return;
    await haptic(); setLoading(true); setError(""); setCopied(false);
    try {
      const uploaded = isImage ? await uploadImage(asset) : await uploadFile(asset);
      setResult(uploaded);
      if (Platform.OS !== "web") await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) { setError(e instanceof Error ? e.message : "Upload failed. Please try again."); }
    finally { setLoading(false); }
  };
  const copy = async () => { if (!result) return; await Clipboard.setStringAsync(result.url); setCopied(true); };
  const open = async () => { if (result) await WebBrowser.openBrowserAsync(result.url); };
  const share = async () => { if (result) await Share.share({ message: result.url, url: result.url, title: "Share link" }); };
  const reset = () => { setAsset(null); setResult(null); setError(""); setCopied(false); };

  return <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-white">
    <View pointerEvents="none" style={styles.backgroundWashTop} /><View pointerEvents="none" style={styles.backgroundWashBottom} />
    <ScrollView contentContainerStyle={styles.uploadContent} showsVerticalScrollIndicator={false}>
      <View style={styles.topBar}>
        <Pressable onPress={onBack} style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Go back"><MaterialIcons name="arrow-back" size={20} color={C.ink} /></Pressable>
        <Text style={styles.topTitle}>{isImage ? "IMAGE → LINK" : "FILE → LINK"}</Text><View style={styles.index}><Text style={styles.indexText}>{isImage ? "01" : "02"}</Text></View>
      </View>
      <Brand compact />
      <View style={styles.intro}><Text style={styles.uploadTitle}>{isImage ? "Upload Image" : "Upload File"}</Text><Text style={styles.uploadSubtitle}>{isImage ? "Select an image from your device" : "Select a file from your device"}</Text></View>

      {!result && !asset && <Pressable onPress={pick} style={({ pressed }) => [styles.dropZone, pressed && styles.dropPressed]} accessibilityRole="button">
        <View style={styles.dropIcon}><MaterialIcons name={isImage ? "add-photo-alternate" : "upload-file"} size={26} color={C.sky} /></View><Text style={styles.dropTitle}>Choose {isImage ? "an image" : "a file"}</Text><Text style={styles.dropHint}>Tap to browse your device</Text><View style={styles.browse}><Text style={styles.browseText}>BROWSE</Text><MaterialIcons name="arrow-forward" size={15} color={C.ink} /></View>
      </Pressable>}

      {!result && asset && <View style={styles.assetPanel}><View style={styles.assetVisual}>{isImage ? <Image source={{ uri: asset.uri }} style={styles.preview} resizeMode="cover" /> : <MaterialIcons name="insert-drive-file" size={30} color={C.ink} />}</View><View style={styles.assetCopy}><Text style={styles.assetName} numberOfLines={2}>{asset.name}</Text><Text style={styles.assetMeta}>{bytes(asset.size)} · {typeLabel(asset)}</Text></View><Pressable onPress={() => setAsset(null)} style={styles.remove} accessibilityRole="button" accessibilityLabel="Remove selected file"><MaterialIcons name="close" size={18} color={C.grey} /></Pressable></View>}
      {!result && asset && <Pressable onPress={upload} disabled={loading} style={({ pressed }) => [styles.primary, (pressed || loading) && styles.pressed]}>{loading ? <ActivityIndicator color={C.white} /> : <MaterialIcons name="link" size={20} color={C.white} />}<Text style={styles.primaryText}>{loading ? "UPLOADING..." : "GENERATE LINK"}</Text></Pressable>}
      {loading && <View style={styles.progress}><View style={styles.progressHeader}><Text style={styles.progressLabel}>UPLOADING {isImage ? "IMAGE" : "FILE"}</Text><Text style={styles.progressValue}>IN PROGRESS</Text></View><View style={styles.track}><View style={styles.fill} /></View><Text style={styles.progressHint}>Keep this screen open while we create your shareable link.</Text></View>}

      {result && <View style={styles.successPanel}><View style={styles.successHeading}><View style={styles.successIcon}><MaterialIcons name="check" size={19} color={C.white} /></View><View><Text style={styles.successEyebrow}>SUCCESS</Text><Text style={styles.successTitle}>LINK GENERATED</Text></View></View><Text style={styles.successIntro}>Your {isImage ? "image" : "file"} is ready to share.</Text><View style={styles.urlBox}><Text style={styles.urlText} numberOfLines={3} selectable>{result.url}</Text><MaterialIcons name="link" size={18} color={C.sky} /></View><Pressable onPress={copy} style={({ pressed }) => [styles.primary, styles.resultPrimary, pressed && styles.pressed]}><MaterialIcons name="content-copy" size={18} color={C.white} /><Text style={styles.primaryText}>COPY LINK</Text></Pressable><View style={styles.secondaryRow}><Pressable onPress={open} style={({ pressed }) => [styles.secondary, pressed && styles.secondaryPressed]}><MaterialIcons name="open-in-new" size={17} color={C.ink} /><Text style={styles.secondaryText}>OPEN LINK</Text></Pressable><Pressable onPress={share} style={({ pressed }) => [styles.secondary, pressed && styles.secondaryPressed]}><MaterialIcons name="share" size={17} color={C.ink} /><Text style={styles.secondaryText}>SHARE</Text></Pressable></View><Pressable onPress={reset} style={({ pressed }) => [styles.another, pressed && styles.pressed]}><Text style={styles.anotherText}>UPLOAD ANOTHER</Text><MaterialIcons name="refresh" size={17} color={C.sky} /></Pressable>{copied && <Text style={styles.copied}>Link copied successfully</Text>}</View>}
      {error ? <View style={styles.error}><MaterialIcons name="error-outline" size={19} color={C.error} /><Text style={styles.errorText}>{error}</Text></View> : null}
    </ScrollView>
  </ScreenContainer>;
}

export default function Index() {
  const [screen, setScreen] = useState<Screen>("home");
  const [fontsLoaded] = useFonts({
    SpaceGrotesk_400Regular,
    SpaceGrotesk_500Medium,
    SpaceGrotesk_600SemiBold,
    SpaceGrotesk_700Bold,
  });
  if (!fontsLoaded) return null;
  return screen === "home" ? <Home onSelect={setScreen} /> : <Upload kind={screen} onBack={() => setScreen("home")} />;
}

const styles = StyleSheet.create({
  backgroundWashTop: { position: "absolute", top: -132, right: -112, width: 320, height: 320, borderRadius: 160, backgroundColor: "#E3F4FB" }, backgroundWashBottom: { position: "absolute", bottom: -170, left: -150, width: 340, height: 340, borderRadius: 170, backgroundColor: "#F0F9FD" },
  homeContent: { paddingHorizontal: 24, paddingTop: 18, paddingBottom: 46 },
  statusRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 28 }, statusDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.sky }, statusText: { color: C.grey, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 10, letterSpacing: 1.6 },
  brand: { marginBottom: 20 }, brandCompact: { marginTop: 8, marginBottom: 28 }, brandRule: { width: 42, height: 4, backgroundColor: C.sky, marginBottom: 14, borderRadius: 2 }, brandName: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 30, lineHeight: 34, letterSpacing: 2.6 }, brandDescriptor: { color: C.grey, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 12, lineHeight: 18, letterSpacing: 2.2, marginTop: 6 }, brandSlash: { color: C.sky },
  hero: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 16, lineHeight: 24, maxWidth: 330, marginBottom: 42 }, sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginBottom: 14 }, eyebrow: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 11, letterSpacing: 1.6 }, sectionHint: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 12 }, cardStack: { gap: 12 },
  featureCard: { minHeight: 112, flexDirection: "row", alignItems: "center", gap: 15, borderWidth: 1, borderColor: "#B9DCEB", borderRadius: 22, backgroundColor: "rgba(255,255,255,0.96)", paddingHorizontal: 16, paddingVertical: 16, shadowColor: "#0B4B68", shadowOpacity: 0.14, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 4 }, featurePressed: { opacity: 0.72, transform: [{ scale: 0.985 }] }, featureIcon: { width: 50, height: 50, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: C.skySoft, borderWidth: 1, borderColor: "#B7DCEC" }, featureCopy: { flex: 1, gap: 5 }, featureTitle: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 15, letterSpacing: 1.2 }, featureDescription: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 13, lineHeight: 19, maxWidth: 230 }, footer: { marginTop: 54 }, footerLine: { height: 1, backgroundColor: C.line, marginBottom: 15 }, footerMeta: { flexDirection: "row", gap: 9, alignItems: "center" }, footerText: { color: C.grey, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 10, letterSpacing: 1.5 }, footerDot: { color: C.sky, fontSize: 11 },
  uploadContent: { paddingHorizontal: 24, paddingTop: 16, paddingBottom: 48 }, topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, back: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: C.line, backgroundColor: "rgba(255,255,255,0.88)" }, pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] }, topTitle: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 12, letterSpacing: 1.4 }, index: { width: 40, height: 40, borderRadius: 12, backgroundColor: C.ink, alignItems: "center", justifyContent: "center" }, indexText: { color: C.white, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 12, letterSpacing: 1 }, intro: { marginBottom: 24 }, uploadTitle: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 28, letterSpacing: 0.1, marginBottom: 7 }, uploadSubtitle: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 14, lineHeight: 20 },
  dropZone: { minHeight: 250, borderWidth: 1, borderColor: "#CFE4ED", borderStyle: "dashed", borderRadius: 22, alignItems: "center", justifyContent: "center", padding: 26, backgroundColor: "rgba(246,249,251,0.9)" }, dropPressed: { backgroundColor: C.skySoft, borderColor: C.sky, transform: [{ scale: 0.99 }] }, dropIcon: { width: 58, height: 58, borderRadius: 17, backgroundColor: C.white, borderWidth: 1, borderColor: "#CDEBF7", alignItems: "center", justifyContent: "center", marginBottom: 17 }, dropTitle: { color: C.ink, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 17, marginBottom: 6 }, dropHint: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 13, marginBottom: 20 }, browse: { flexDirection: "row", gap: 8, alignItems: "center", paddingBottom: 3, borderBottomWidth: 1, borderBottomColor: C.sky }, browseText: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 11, letterSpacing: 1.5 },
  assetPanel: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: C.line, borderRadius: 18, padding: 12, backgroundColor: "rgba(246,249,251,0.94)", minHeight: 88 }, assetVisual: { width: 62, height: 62, borderRadius: 14, backgroundColor: C.white, alignItems: "center", justifyContent: "center", overflow: "hidden" }, preview: { width: 62, height: 62 }, assetCopy: { flex: 1, paddingHorizontal: 13, gap: 5 }, assetName: { color: C.ink, fontFamily: "SpaceGrotesk_600SemiBold", fontSize: 14, lineHeight: 19 }, assetMeta: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 12 }, remove: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" }, primary: { minHeight: 54, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, backgroundColor: C.ink, paddingHorizontal: 20, marginTop: 16, shadowColor: C.ink, shadowOpacity: 0.16, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 3 }, primaryText: { color: C.white, fontFamily: "SpaceGrotesk_700Bold", fontSize: 12, letterSpacing: 1.35 },
  progress: { marginTop: 18, padding: 16, borderRadius: 16, backgroundColor: C.skySoft, borderLeftWidth: 3, borderLeftColor: C.sky }, progressHeader: { flexDirection: "row", justifyContent: "space-between", marginBottom: 11 }, progressLabel: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 10, letterSpacing: 1.2 }, progressValue: { color: C.grey, fontFamily: "SpaceGrotesk_500Medium", fontSize: 10, letterSpacing: 0.8 }, track: { height: 4, borderRadius: 2, backgroundColor: C.white, overflow: "hidden" }, fill: { height: 4, width: "62%", backgroundColor: C.sky }, progressHint: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 12, lineHeight: 18, marginTop: 11 },
  successPanel: { borderWidth: 1, borderColor: C.line, borderRadius: 20, padding: 18, backgroundColor: "rgba(255,255,255,0.96)", shadowColor: "#10222E", shadowOpacity: 0.08, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 3 }, successHeading: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 13 }, successIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: C.success, alignItems: "center", justifyContent: "center" }, successEyebrow: { color: C.success, fontFamily: "SpaceGrotesk_700Bold", fontSize: 9, letterSpacing: 1.5, marginBottom: 2 }, successTitle: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 17, letterSpacing: 1.2 }, successIntro: { color: C.grey, fontFamily: "SpaceGrotesk_400Regular", fontSize: 13, marginBottom: 14 }, urlBox: { minHeight: 76, borderRadius: 13, flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderColor: C.ink, padding: 13, backgroundColor: C.soft }, urlText: { flex: 1, color: C.ink, fontFamily: "SpaceGrotesk_500Medium", fontSize: 13, lineHeight: 19 }, resultPrimary: { marginTop: 14 }, secondaryRow: { flexDirection: "row", gap: 10, marginTop: 10 }, secondary: { flex: 1, minHeight: 47, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1, borderColor: C.line, backgroundColor: C.white }, secondaryPressed: { backgroundColor: C.soft, transform: [{ scale: 0.985 }] }, secondaryText: { color: C.ink, fontFamily: "SpaceGrotesk_700Bold", fontSize: 10, letterSpacing: 1 }, another: { minHeight: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 9 }, anotherText: { color: C.sky, fontFamily: "SpaceGrotesk_700Bold", fontSize: 11, letterSpacing: 1.2 }, copied: { color: C.success, fontFamily: "SpaceGrotesk_500Medium", fontSize: 12, textAlign: "center", marginTop: 1 }, error: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 13, borderRadius: 14, backgroundColor: "#FFF4F2", borderLeftWidth: 3, borderLeftColor: C.error, marginTop: 16 }, errorText: { flex: 1, color: C.error, fontFamily: "SpaceGrotesk_500Medium", fontSize: 12, lineHeight: 18 },
});
