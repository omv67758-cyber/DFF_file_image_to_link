import type { Express, Request, Response } from "express";
import multer from "multer";
import { storagePut, storageGetSignedUrl } from "./storage";

const MAX_IMAGE_BYTES = 32 * 1024 * 1024;
const MAX_FILE_BYTES = 50 * 1024 * 1024;

const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES },
});

const fileUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_BYTES },
});

function jsonError(res: Response, status: number, message: string) {
  return res.status(status).json({ error: message });
}

function safeFilename(name: string) {
  return name
    .normalize("NFKD")
    .replace(/[^a-zA-Z0-9._-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^\.+/, "")
    .slice(0, 120) || "file";
}

function imageExtension(mimeType: string) {
  const value = mimeType.split("/")[1]?.split(";")[0] || "jpg";
  return value === "jpeg" ? "jpg" : value.replace(/[^a-z0-9]/gi, "") || "jpg";
}

async function uploadImageToImgBB(file: Express.Multer.File) {
  const apiKey = process.env.IMGBB_API_KEY;
  if (!apiKey) throw new Error("Image upload is not configured on the server.");

  const body = new FormData();
  body.append("image", new Blob([new Uint8Array(file.buffer)], { type: file.mimetype }), file.originalname);
  const url = new URL("https://api.imgbb.com/1/upload");
  url.searchParams.set("key", apiKey);

  const response = await fetch(url, { method: "POST", body });
  const payload = (await response.json().catch(() => ({}))) as {
    success?: boolean;
    data?: { url?: string };
    error?: { message?: string };
  };
  if (!response.ok || !payload.success || !payload.data?.url) {
    throw new Error(payload.error?.message || "ImgBB could not accept this image.");
  }
  return payload.data.url;
}

export function registerUploadRoutes(app: Express) {
  app.post("/api/upload/image", imageUpload.single("file"), async (req: Request, res: Response) => {
    try {
      const file = req.file;
      if (!file) return jsonError(res, 400, "Choose an image before uploading.");
      if (!file.mimetype.startsWith("image/")) return jsonError(res, 415, "Only image files are supported here.");
      const url = await uploadImageToImgBB(file);
      return res.json({ url, name: file.originalname, size: file.size, mimeType: file.mimetype });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Image upload failed.";
      return jsonError(res, 500, message);
    }
  });

  app.post("/api/upload/file", fileUpload.single("file"), async (req: Request, res: Response) => {
    try {
      const file = req.file;
      if (!file) return jsonError(res, 400, "Choose a file before uploading.");
      const uniqueKey = `uploads/${crypto.randomUUID()}-${safeFilename(file.originalname)}`;
      await storagePut(uniqueKey, file.buffer, file.mimetype || "application/octet-stream");
      return res.json({
        url: `/files/${encodeURIComponent(uniqueKey)}`,
        name: file.originalname,
        size: file.size,
        mimeType: file.mimetype || "application/octet-stream",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "File upload failed.";
      return jsonError(res, 500, message);
    }
  });

  app.get("/files/:key(*)", async (req: Request, res: Response) => {
    try {
      const key = decodeURIComponent(req.params.key);
      if (!key.startsWith("uploads/") || key.includes("..")) return jsonError(res, 400, "Invalid file link.");
      const signedUrl = await storageGetSignedUrl(key);
      return res.redirect(307, signedUrl);
    } catch {
      return jsonError(res, 404, "File not found.");
    }
  });
}
